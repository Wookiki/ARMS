package arms.web.login.vo;

public class UserInfo {
	private String u_id;
	private String u_passwd;
	private String u_name;
	private String u_dong;
	private int u_ho;
	private String u_tel;
	private int u_car;
	private String u_hostId;
	private String u_presidentId;
	private String u_adminId;
	private boolean adminCheck;
	
	public String getU_id() {
		return u_id;
	}
	public void setU_id(String u_id) {
		this.u_id = u_id;
	}
	public String getU_passwd() {
		return u_passwd;
	}
	public void setU_passwd(String u_passwd) {
		this.u_passwd = u_passwd;
	}
	public String getU_name() {
		return u_name;
	}
	public void setU_name(String u_name) {
		this.u_name = u_name;
	}
	public String getU_dong() {
		return u_dong;
	}
	public void setU_dong(String u_dong) {
		this.u_dong = u_dong;
	}
	public int getU_ho() {
		return u_ho;
	}
	public void setU_ho(int u_ho) {
		this.u_ho = u_ho;
	}
	public String getU_tel() {
		return u_tel;
	}
	public void setU_tel(String u_tel) {
		this.u_tel = u_tel;
	}
	public int getU_car() {
		return u_car;
	}
	public void setU_car(int u_car) {
		this.u_car = u_car;
	}
	public String getU_hostId() {
		return u_hostId;
	}
	public void setU_hostId(String u_hostId) {
		this.u_hostId = u_hostId;
	}
	public String getU_presidentId() {
		return u_presidentId;
	}
	public void setU_presidentId(String u_presidentId) {
		this.u_presidentId = u_presidentId;
	}
	public String getU_adminId() {
		return u_adminId;
	}
	public void setU_adminId(String u_adminId) {
		this.u_adminId = u_adminId;
	}
	public boolean isAdminCheck() {
		return adminCheck;
	}
	public void setAdminCheck(boolean adminCheck) {
		this.adminCheck = adminCheck;
	}
}
