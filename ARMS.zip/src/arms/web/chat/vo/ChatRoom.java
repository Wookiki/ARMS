package arms.web.chat.vo;

public class ChatRoom {
	private String ch_topic;
	private String ch_host;
	private String ch_participant;
	
	public String getCh_topic() {
		return ch_topic;
	}
	public void setCh_topic(String ch_topic) {
		this.ch_topic = ch_topic;
	}
	public String getCh_host() {
		return ch_host;
	}
	public void setCh_host(String ch_host) {
		this.ch_host = ch_host;
	}
	public String getCh_participant() {
		return ch_participant;
	}
	public void setCh_participant(String ch_participant) {
		this.ch_participant = ch_participant;
	}
}
